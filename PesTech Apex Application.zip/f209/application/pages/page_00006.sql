prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(146140362370837412)
,p_name=>'TEST CAL'
,p_alias=>'TEST-CAL'
,p_step_title=>'TEST CAL'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DARRENWALSH@OUTLOOK.IE'
,p_last_upd_yyyymmddhh24miss=>'20210428225550'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(226049660062631990)
,p_plug_name=>'TEST CAL'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146055105207837253)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'With Account_balance as (SELECT',
'     w.workorder_id,',
'     w.customer_id,',
'    SUM(pd.amount) AS balance',
'FROM',
'         pt_payment_details pd',
'    INNER JOIN  pt_workorders w ON pd.workorder_id =  w.workorder_id',
'GROUP BY',
'     w.workorder_id,',
'     w.customer_id)',
'     ',
'     SELECT distinct ',
'    nvl(c.company, c.first_name',
'                   || '' ''',
'                   || c.last_name)           AS customer,',
'    w.details,',
'    w.amount,',
'    to_date(to_char(to_char(s.schedule_date,''DD-MON-YY'')||'' ''||to_char(s.schedule_time)),''DD-MON-YYYY hh24:MI:SS'') Scheduled_Datetime,',
'    --s.schedule_time,',
'    e.first_name',
'    || '' ''',
'    || e.last_name            AS employee,',
'    cc.cc_id,',
'    w.workorder_id,',
'    ws.status,',
'    case when w.amount - nvl(ab.balance,0) = 0 then null else w.amount - nvl(ab.balance,0) end  AS account_balance,',
'    case when  w.amount - nvl(ab.balance,0) != 0.00 then ''Make Payment'' else null end AS "Make Payment"',
'FROM',
'         pt_customers c',
'    INNER JOIN pt_customer_contracts  cc ON c.custid = cc.custid',
'    INNER JOIN pt_workorders          w ON cc.custid = w.customer_id',
'                                  AND cc.cc_id = w.customer_contract_id',
'    LEFT JOIN pt_schedule            s ON w.workorder_id = s.workorder_id',
'    INNER JOIN pt_employees           e ON s.empid = e.empid',
'    INNER JOIN pt_workorder_status    ws ON w.status_id = ws.status_id',
'    LEFT JOIN pt_payment_details     pd ON w.workorder_id = pd.workorder_id',
'    left join Account_balance ab on ab.customer_id = c.custid and ab.workorder_id = w.workorder_id'))
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'SCHEDULED_DATETIME'
,p_attribute_02=>'SCHEDULED_DATETIME'
,p_attribute_03=>'CUSTOMER'
,p_attribute_11=>'month:week:day:list:navigation'
,p_attribute_13=>'Y'
,p_attribute_17=>'Y'
,p_attribute_18=>'00'
,p_attribute_19=>'Y'
,p_attribute_20=>'9'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_api.component_end;
end;
/
