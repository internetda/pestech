prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(146140362370837412)
,p_name=>'Workorder Calendar'
,p_alias=>'WORKORDER-CALENDAR'
,p_step_title=>'Workorder Calendar'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(146436739399778825)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DARRENWALSH@OUTLOOK.IE'
,p_last_upd_yyyymmddhh24miss=>'20210429143550'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(221569833469062999)
,p_plug_name=>'Workorder Calendar'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146055105207837253)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    s.schedule_id,',
'    s.empid,',
'    s.schedule_date,',
'    s.schedule_time display_time,',
'    TO_CHAR(TO_DATE(s.schedule_time, ''HH24:MI:SS''), ''DD-MON-YYYY HH24:MI:SS'') schedule_time, ',
'    s.customer_contract_id,',
'    s.workorder_id,',
'    s.custid,',
'    e.first_name||'' ''||e.Last_name as Technican,',
'    co.contract_name,',
'    ct.call_type,',
'    ws.status,',
'    CASE WHEN c.company IS NULL THEN  c.first_name||'' ''||c.last_name',
'    ELSE c.company END AS Customer,',
'    w.amount Workorder_Charge,',
'    w.details Workorder_Details',
'FROM',
'         pt_schedule s',
'    INNER JOIN pt_employees e ON s.empid = e.empid',
'    INNER JOIN pt_customer_contracts cc ON s.customer_contract_id = cc.cc_id',
'    INNER JOIN pt_contracts co ON cc.contract_id = co.contract_id',
'    INNER JOIN pt_workorders w ON s.workorder_id = w.workorder_id',
'    INNER JOIN pt_call_type ct ON w.call_type_id = ct.call_type_id',
'    INNER JOIN pt_workorder_status ws ON w.status_id = ws.status_id',
'    INNER JOIN pt_customers c ON s.custid = c.custid'))
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'SCHEDULE_DATE'
,p_attribute_02=>'SCHEDULE_DATE'
,p_attribute_03=>'CUSTOMER'
,p_attribute_04=>'WORKORDER_ID'
,p_attribute_05=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::P22_SCHEDULE_ID,P22_CUSTOMER_CONTRACT_ID,P22_EMPID,P22_SCHEDULE_DATE,P22_SCHEDULE_TIME,P22_WORKORDER_ID:&SCHEDULE_ID.,&CUSTOMER_CONTRACT_ID.,&EMPID.,&SCHEDULE_DATE.,&SCHEDULE_TIME.,&WORKORDER_ID.'
,p_attribute_07=>'N'
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_16=>'Time: &DISPLAY_TIME.'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_api.component_end;
end;
/
