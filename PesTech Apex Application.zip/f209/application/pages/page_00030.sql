prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page(
 p_id=>30
,p_user_interface_id=>wwv_flow_api.id(146140362370837412)
,p_name=>'Customer Workorders'
,p_alias=>'CUSTOMER-WORKORDERS'
,p_step_title=>'Customer Workorders'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}'))
,p_step_template=>wwv_flow_api.id(146000946000837164)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DARRENWALSH@OUTLOOK.IE'
,p_last_upd_yyyymmddhh24miss=>'20210416191230'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(212739879825482605)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(146064578161837266)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(146000170949837157)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(146119090339837331)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(212741259954482618)
,p_plug_name=>'Search'
,p_region_css_classes=>'search-region padding-md'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146026719897837228)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(212742069045482621)
,p_name=>'Master Records'
,p_template=>wwv_flow_api.id(146026949453837229)
,p_display_sequence=>20
,p_region_css_classes=>'search-results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'t-MediaList--showDesc:t-MediaList--stack'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTID,',
'    null link_class,',
'    apex_page.get_url(p_items => ''P30_CUSTID'', p_values => CUSTID) link,',
'    null icon_class,',
'    null link_attr,',
'    null icon_color_class,',
'    case when nvl(:P30_CUSTID,''0'') = CUSTID',
'      then ''is-active'' ',
'      else '' ''',
'    end list_class,',
'    substr(COMPANY, 1, 50)||( case when length(COMPANY) > 50 then ''...'' when COMPANY is null then First_Name ||'' '' || Last_Name end ) list_title,    ',
'    c.address_1 as list_text,     ',
'    null list_badge',
'from PT_CUSTOMERS c',
'join pt_account_status acs on acs.ACCOUNT_STATUS_ID = c.ACCOUNT_STATUS_ID',
'where (:P30_SEARCH is null',
'        or upper(c.COMPANY) like ''%''||upper(:P30_SEARCH)||''%''',
'        or upper(c.TOWN_CITY) like ''%''||upper(:P30_SEARCH)||''%''',
'    )',
'order by COMPANY'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P30_SEARCH'
,p_query_row_template=>wwv_flow_api.id(146080874880837285)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'<div class="u-tC">No Records Found</div>'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212742798233482628)
,p_query_column_id=>1
,p_column_alias=>'CUSTID'
,p_column_display_sequence=>1
,p_column_heading=>'CUSTID'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212743188386482630)
,p_query_column_id=>2
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>2
,p_column_heading=>'LINK_CLASS'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212743561341482630)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_heading=>'LINK'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212743905607482630)
,p_query_column_id=>4
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>4
,p_column_heading=>'ICON_CLASS'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212744359822482630)
,p_query_column_id=>5
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>5
,p_column_heading=>'LINK_ATTR'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212744720626482630)
,p_query_column_id=>6
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>6
,p_column_heading=>'ICON_COLOR_CLASS'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212745171925482631)
,p_query_column_id=>7
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>7
,p_column_heading=>'LIST_CLASS'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212745562892482631)
,p_query_column_id=>8
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>8
,p_column_heading=>'LIST_TITLE'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212745954821482631)
,p_query_column_id=>9
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>9
,p_column_heading=>'LIST_TEXT'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212746370304482631)
,p_query_column_id=>10
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>10
,p_column_heading=>'LIST_BADGE'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(212746701999482638)
,p_name=>'Customer Detail'
,p_template=>wwv_flow_api.id(146055105207837253)
,p_display_sequence=>10
,p_region_css_classes=>'js-master-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select CUSTID,',
'       ACCOUNT_STATUS_ID,',
'       CUST_TYPE_ID,',
'       nvl(company, ''<Domesctic Customer>'')  AS company,',
'       SALUTATION ||'' ''||FIRST_NAME||'' '' ||LAST_NAME CustomerName,',
'        ADDRESS_1 || decode(ADDRESS_2, null, null, '', '' || ADDRESS_2)||'', ''||TOWN_CITY||'', ''||co.COUNTY ||''''||decode(eircode, null, null, '', '' || eircode) Address, ',
'      PHONE,',
'       MOBILE,',
'       EMAIL,',
'--       ADDRESS_1,',
'--       ADDRESS_2,',
'--       TOWN_CITY,',
'--       co.COUNTY,',
'--       EIRCODE,',
'       CREATED,',
'       CREATED_BY,',
'       UPDATED,',
'       UPDATE_BY',
'  from PT_CUSTOMERS c',
'  join pt_counties co on co.county_id = c.county',
' where "CUSTID" = :P30_CUSTID'))
,p_display_when_condition=>'P30_CUSTID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(146087085731837290)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Record Selected'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212747435408482639)
,p_query_column_id=>1
,p_column_alias=>'CUSTID'
,p_column_display_sequence=>1
,p_column_heading=>'Custid'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "CUSTID" is not null',
'and "CUSTID" = :P30_CUSTID'))
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212747869209482640)
,p_query_column_id=>2
,p_column_alias=>'ACCOUNT_STATUS_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "ACCOUNT_STATUS_ID" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212748275138482641)
,p_query_column_id=>3
,p_column_alias=>'CUST_TYPE_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Customer Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "CUST_TYPE_ID" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(146203015021864849)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212748695773482641)
,p_query_column_id=>4
,p_column_alias=>'COMPANY'
,p_column_display_sequence=>4
,p_column_heading=>'Company'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "COMPANY" is not null',
'and "CUSTID" = :P30_CUSTID'))
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(211753091241406448)
,p_query_column_id=>5
,p_column_alias=>'CUSTOMERNAME'
,p_column_display_sequence=>29
,p_column_heading=>'Contact Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(211753195252406449)
,p_query_column_id=>6
,p_column_alias=>'ADDRESS'
,p_column_display_sequence=>39
,p_column_heading=>'Address'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212750253523482641)
,p_query_column_id=>7
,p_column_alias=>'PHONE'
,p_column_display_sequence=>8
,p_column_heading=>'Phone'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "PHONE" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212750602962482641)
,p_query_column_id=>8
,p_column_alias=>'MOBILE'
,p_column_display_sequence=>9
,p_column_heading=>'Mobile'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "MOBILE" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212751005566482642)
,p_query_column_id=>9
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>10
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "EMAIL" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212753449734482644)
,p_query_column_id=>10
,p_column_alias=>'CREATED'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "CREATED" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212753804706482644)
,p_query_column_id=>11
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "CREATED_BY" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212754253221482644)
,p_query_column_id=>12
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "UPDATED" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212754659341482645)
,p_query_column_id=>13
,p_column_alias=>'UPDATE_BY'
,p_column_display_sequence=>19
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "PT_CUSTOMERS"',
'where "UPDATE_BY" is not null',
'and "CUSTID" = :P30_CUSTID'))
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(212767168792482661)
,p_plug_name=>'Region Display Selector'
,p_region_css_classes=>'js-detail-rds'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146026719897837228)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P30_CUSTID'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(212767596414482661)
,p_name=>'Contract Details'
,p_template=>wwv_flow_api.id(146055105207837253)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'PT_CUSTOMER_CONTRACTS'
,p_query_where=>'"CUSTID" = :P30_CUSTID'
,p_include_rowid_column=>true
,p_display_when_condition=>'P30_CUSTID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(146084028827837288)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>5000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212768395385482670)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_heading=>'<span class="u-VisuallyHidden">Edit</span>'
,p_column_link=>'f?p=&APP_ID.:53:&APP_SESSION.::&DEBUG.:RP:P53_ROWID:#ROWID#'
,p_column_linktext=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_heading_alignment=>'LEFT'
,p_report_column_width=>32
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212768794374482670)
,p_query_column_id=>2
,p_column_alias=>'CC_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212769103542482670)
,p_query_column_id=>3
,p_column_alias=>'CONTRACT_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Contact'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(146433982143549982)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212769532178482670)
,p_query_column_id=>4
,p_column_alias=>'CUSTID'
,p_column_display_sequence=>4
,p_column_heading=>'Custid'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212769921621482670)
,p_query_column_id=>5
,p_column_alias=>'START_DATE'
,p_column_display_sequence=>5
,p_column_heading=>'Start Date'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212770324448482670)
,p_query_column_id=>6
,p_column_alias=>'RENEWAL_DATE'
,p_column_display_sequence=>6
,p_column_heading=>'Renewal Date'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212770738242482670)
,p_query_column_id=>7
,p_column_alias=>'ANNUAL_FEE'
,p_column_display_sequence=>7
,p_column_heading=>'Annual Fee'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212771188896482671)
,p_query_column_id=>8
,p_column_alias=>'REP_ID'
,p_column_display_sequence=>8
,p_column_heading=>'Technican'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(146434394449582699)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212771500445482671)
,p_query_column_id=>9
,p_column_alias=>'CREATED'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212771951605482671)
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212772373002482671)
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212772771330482671)
,p_query_column_id=>12
,p_column_alias=>'UPDATE_BY'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(212792957801482723)
,p_name=>'Workorders'
,p_template=>wwv_flow_api.id(146055105207837253)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'PT_WORKORDERS'
,p_query_where=>'CUSTOMER_ID = :P30_CUSTID'
,p_include_rowid_column=>true
,p_display_when_condition=>'P30_CUSTID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(146084028827837288)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>5000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212793740052482730)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_heading=>'<span class="u-VisuallyHidden">Edit</span>'
,p_column_link=>'f?p=&APP_ID.:54:&APP_SESSION.::&DEBUG.:RP:P54_ROWID:#ROWID#'
,p_column_linktext=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_heading_alignment=>'LEFT'
,p_report_column_width=>32
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212794137295482730)
,p_query_column_id=>2
,p_column_alias=>'WORKORDER_ID'
,p_column_display_sequence=>2
,p_column_heading=>'WorkorderID'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212794563555482730)
,p_query_column_id=>3
,p_column_alias=>'CALL_TYPE_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Call Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select CALL_TYPE d, CALL_TYPE_ID r ',
'  from PT_CALL_TYPE '))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212794901121482731)
,p_query_column_id=>4
,p_column_alias=>'CUSTOMER_ID'
,p_column_display_sequence=>4
,p_column_heading=>'Customer Id'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212795367153482731)
,p_query_column_id=>5
,p_column_alias=>'DETAILS'
,p_column_display_sequence=>5
,p_column_heading=>'Workorder Details'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212795799809482731)
,p_query_column_id=>6
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>6
,p_column_heading=>'Charge'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212796140150482731)
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212796519255482731)
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212796944758482731)
,p_query_column_id=>9
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212797345376482732)
,p_query_column_id=>10
,p_column_alias=>'UPDATE_BY'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212797705922482732)
,p_query_column_id=>11
,p_column_alias=>'CUSTOMER_CONTRACT_ID'
,p_column_display_sequence=>11
,p_column_heading=>'Customer Contract'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'       SELECT',
'   co.contract_name d,    ',
'    cc.cc_id r',
'FROM',
'         pt_customer_contracts cc',
'    --INNER JOIN pt_customer_contracts cc ON c.custid = cc.custid',
'    INNER JOIN pt_contracts co ON cc.contract_id = co.contract_id',
'    where   cc.custid = :P30_CUSTID ',
'    '))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212798194426482732)
,p_query_column_id=>12
,p_column_alias=>'STATUS_ID'
,p_column_display_sequence=>12
,p_column_heading=>'Workorder Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(212870780997892663)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(212818435336482788)
,p_name=>'Schedule'
,p_template=>wwv_flow_api.id(146055105207837253)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'PT_SCHEDULE'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'"CUSTID" = :P30_CUSTID',
''))
,p_include_rowid_column=>true
,p_display_when_condition=>'P30_CUSTID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(146084028827837288)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>5000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212819101825482798)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_heading=>'<span class="u-VisuallyHidden">Edit</span>'
,p_column_link=>'f?p=&APP_ID.:55:&APP_SESSION.::&DEBUG.:RP:P55_ROWID:#ROWID#'
,p_column_linktext=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_heading_alignment=>'LEFT'
,p_report_column_width=>32
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212819521664482798)
,p_query_column_id=>2
,p_column_alias=>'SCHEDULE_ID'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212819948787482798)
,p_query_column_id=>3
,p_column_alias=>'EMPID'
,p_column_display_sequence=>31
,p_column_heading=>'Assigned Employee'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(146434394449582699)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212820309470482798)
,p_query_column_id=>4
,p_column_alias=>'SCHEDULE_DATE'
,p_column_display_sequence=>41
,p_column_heading=>'Schedule Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212820782188482799)
,p_query_column_id=>5
,p_column_alias=>'SCHEDULE_TIME'
,p_column_display_sequence=>51
,p_column_heading=>'Schedule Time'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212821183127482799)
,p_query_column_id=>6
,p_column_alias=>'CUSTOMER_CONTRACT_ID'
,p_column_display_sequence=>61
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212821584372482799)
,p_query_column_id=>7
,p_column_alias=>'WORKORDER_ID'
,p_column_display_sequence=>11
,p_column_heading=>'WorkorderID'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(212821912858482799)
,p_query_column_id=>8
,p_column_alias=>'CUSTID'
,p_column_display_sequence=>71
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(212838252168482840)
,p_plug_name=>'No Record Selected'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146026719897837228)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>'No Record Selected'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P30_CUSTID'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(212777471968482674)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(212767596414482661)
,p_button_name=>'POP_PT_CUSTOMER_CONTRACTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(146116970219837327)
,p_button_image_alt=>'Add Pt Customer Contracts'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:53:&APP_SESSION.::&DEBUG.:RP,53:P53_CUSTID:&P30_CUSTID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(212802893893482738)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(212792957801482723)
,p_button_name=>'POP_PT_WORKORDERS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(146116970219837327)
,p_button_image_alt=>'Add Pt Workorders'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:54:&APP_SESSION.::&DEBUG.:RP,54:P54_CUSTOMER_ID:&P30_CUSTID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(212825479597482801)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(212818435336482788)
,p_button_name=>'POP_PT_SCHEDULE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(146116970219837327)
,p_button_image_alt=>'Add Pt Schedule'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:55:&APP_SESSION.::&DEBUG.:RP,55:P55_CUSTID:&P30_CUSTID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(212838796649482840)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(212746701999482638)
,p_button_name=>'EDIT'
,p_button_static_id=>'edit_master_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(146117796349837330)
,p_button_image_alt=>'Edit'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:52:&APP_SESSION.::&DEBUG.:RP,52:P52_CUSTID:&P30_CUSTID.'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(212740573679482614)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(212739879825482605)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--gapRight'
,p_button_template_id=>wwv_flow_api.id(146117796349837330)
,p_button_image_alt=>'Reset'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:30:&APP_SESSION.:RESET:&DEBUG.:RP,30::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(212740956100482617)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(212739879825482605)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(146117796349837330)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:52:&APP_SESSION.::&DEBUG.:RP,52::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(212741665993482620)
,p_name=>'P30_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(212741259954482618)
,p_prompt=>'Search'
,p_placeholder=>'Search...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(146116246960837322)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--postTextBlock'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(212766717252482660)
,p_name=>'P30_CUSTID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(212746701999482638)
,p_display_as=>'NATIVE_HIDDEN'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(212839062537482840)
,p_name=>'Edit Master Record'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(212746701999482638)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212839656568482840)
,p_event_id=>wwv_flow_api.id(212839062537482840)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(212746701999482638)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212840145752482841)
,p_event_id=>wwv_flow_api.id(212839062537482840)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Pt\u0020Customers\u0020updated'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(212767646135482661)
,p_name=>'Refresh on Dialog Close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(212767596414482661)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212778120129482674)
,p_event_id=>wwv_flow_api.id(212767646135482661)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(212767596414482661)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212778696382482674)
,p_event_id=>wwv_flow_api.id(212767646135482661)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Pt Customer Contracts updated'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(212793025891482723)
,p_name=>'Refresh on Dialog Close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(212792957801482723)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212803533976482738)
,p_event_id=>wwv_flow_api.id(212793025891482723)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(212792957801482723)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212804007366482738)
,p_event_id=>wwv_flow_api.id(212793025891482723)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Pt Workorders updated'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(212818579916482788)
,p_name=>'Refresh on Dialog Close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(212818435336482788)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212826132992482801)
,p_event_id=>wwv_flow_api.id(212818579916482788)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(212818435336482788)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212826609840482801)
,p_event_id=>wwv_flow_api.id(212818579916482788)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Pt Schedule updated'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(212839158243482840)
,p_name=>'Perform Search'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P30_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which === apex.jQuery.ui.keyCode.ENTER'
,p_bind_type=>'bind'
,p_bind_event_type=>'keypress'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212840999904482841)
,p_event_id=>wwv_flow_api.id(212839158243482840)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(212742069045482621)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(212841464850482841)
,p_event_id=>wwv_flow_api.id(212839158243482840)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_api.component_end;
end;
/
