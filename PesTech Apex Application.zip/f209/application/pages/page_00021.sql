prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page(
 p_id=>21
,p_user_interface_id=>wwv_flow_api.id(146140362370837412)
,p_name=>'Workorder Schedule'
,p_alias=>'WORKORDER-SCHEDULE'
,p_step_title=>'Workorder Schedule'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(146436739399778825)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DARRENWALSH@OUTLOOK.IE'
,p_last_upd_yyyymmddhh24miss=>'20210429141526'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(215060503428661060)
,p_plug_name=>'Workorder Schedule Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(146053293832837252)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    s.schedule_id,',
'    s.empid,',
'    s.schedule_date,',
'    s.schedule_time display_time,',
'    TO_CHAR(TO_DATE(s.schedule_time, ''HH24:MI:SS''), ''DD-MON-YYYY HH24:MI:SS'') schedule_time, ',
'    s.customer_contract_id,',
'    s.workorder_id,',
'    s.custid,',
'    e.first_name||'' ''||e.Last_name as Technican,',
'    co.contract_name,',
'    ct.call_type,',
'    ws.status,',
'    CASE WHEN c.company IS NULL THEN  c.first_name||'' ''||c.last_name',
'    ELSE c.company END AS Customer,',
'    w.amount Workorder_Charge,',
'    w.details Workorder_Details',
'FROM',
'         pt_schedule s',
'    INNER JOIN pt_employees e ON s.empid = e.empid',
'    INNER JOIN pt_customer_contracts cc ON s.customer_contract_id = cc.cc_id',
'    INNER JOIN pt_contracts co ON cc.contract_id = co.contract_id',
'    INNER JOIN pt_workorders w ON s.workorder_id = w.workorder_id',
'    INNER JOIN pt_call_type ct ON w.call_type_id = ct.call_type_id',
'    INNER JOIN pt_workorder_status ws ON w.status_id = ws.status_id',
'    INNER JOIN pt_customers c ON s.custid = c.custid'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Workorder Schedule Report'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(215060989762661062)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP:P22_SCHEDULE_ID:\#SCHEDULE_ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'DARRENWALSH@OUTLOOK.IE'
,p_internal_uid=>215060989762661062
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215061082323661064)
,p_db_column_name=>'SCHEDULE_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Schedule Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215061483019661065)
,p_db_column_name=>'EMPID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Empid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215062601198661070)
,p_db_column_name=>'CUSTOMER_CONTRACT_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Customer Contract Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215063055872661070)
,p_db_column_name=>'WORKORDER_ID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'WorkorderID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215063492645661070)
,p_db_column_name=>'CUSTID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Custid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605135472323841)
,p_db_column_name=>'TECHNICAN'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Technican'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605266618323842)
,p_db_column_name=>'CONTRACT_NAME'
,p_display_order=>27
,p_column_identifier=>'I'
,p_column_label=>'Contract Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605315473323843)
,p_db_column_name=>'CALL_TYPE'
,p_display_order=>37
,p_column_identifier=>'J'
,p_column_label=>'Call Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605437758323844)
,p_db_column_name=>'STATUS'
,p_display_order=>47
,p_column_identifier=>'K'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605569174323845)
,p_db_column_name=>'CUSTOMER'
,p_display_order=>57
,p_column_identifier=>'L'
,p_column_label=>'Customer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605672540323846)
,p_db_column_name=>'WORKORDER_CHARGE'
,p_display_order=>67
,p_column_identifier=>'M'
,p_column_label=>'Workorder Charge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605721585323847)
,p_db_column_name=>'WORKORDER_DETAILS'
,p_display_order=>77
,p_column_identifier=>'N'
,p_column_label=>'Workorder Details'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605940402323849)
,p_db_column_name=>'SCHEDULE_DATE'
,p_display_order=>97
,p_column_identifier=>'P'
,p_column_label=>'Schedule Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220606095454323850)
,p_db_column_name=>'SCHEDULE_TIME'
,p_display_order=>107
,p_column_identifier=>'Q'
,p_column_label=>'Schedule Time(Cal)'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(226619495237177301)
,p_db_column_name=>'DISPLAY_TIME'
,p_display_order=>117
,p_column_identifier=>'R'
,p_column_label=>'Schedule Time'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(215066273980661571)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2150663'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKORDER_ID:CUSTOMER:CALL_TYPE:WORKORDER_DETAILS:WORKORDER_CHARGE:TECHNICAN:SCHEDULE_DATE:SCHEDULE_TIME:STATUS:DISPLAY_TIME'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(215065812863661081)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(215060503428661060)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(146117652757837330)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22'
);
wwv_flow_api.component_end;
end;
/
