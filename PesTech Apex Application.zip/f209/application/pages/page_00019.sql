prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page(
 p_id=>19
,p_user_interface_id=>wwv_flow_api.id(146140362370837412)
,p_name=>'Customer Workorders'
,p_alias=>'CUSTOMER-WORKORDERS1'
,p_step_title=>'Customer Workorders'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(146436739399778825)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DARRENWALSH@OUTLOOK.IE'
,p_last_upd_yyyymmddhh24miss=>'20210426221228'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(215023496746493292)
,p_plug_name=>'Customer Workorders'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(146053293832837252)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'With Account_balance as (SELECT',
'     w.workorder_id,',
'     w.customer_id,',
'    SUM(pd.amount) AS balance',
'FROM',
'         pt_payment_details pd',
'    INNER JOIN  pt_workorders w ON pd.workorder_id =  w.workorder_id',
'GROUP BY',
'     w.workorder_id,',
'     w.customer_id)',
'     ',
'     SELECT distinct ',
'    nvl(c.company, c.first_name',
'                   || '' ''',
'                   || c.last_name)           AS customer,',
'                   c.address_1 ||'', ''||c.town_city as Location,',
'    w.details,',
'    w.amount,',
'    s.schedule_date,',
'    s.schedule_time,',
'    e.first_name',
'    || '' ''',
'    || e.last_name            AS employee,',
'    cc.cc_id,',
'    w.workorder_id,',
'    ws.status,',
'    case when w.amount - nvl(ab.balance,0) = 0 then null else w.amount - nvl(ab.balance,0) end  AS account_balance,',
'    case when  w.amount - nvl(ab.balance,0) != 0.00 then ''Make Payment'' else null end AS "Make Payment",',
'    case when ws.status_ID != 2 then ''View Schedule'' else null end AS "View Schedule"',
'FROM',
'         pt_customers c',
'    INNER JOIN pt_customer_contracts  cc ON c.custid = cc.custid',
'    INNER JOIN pt_workorders          w ON cc.custid = w.customer_id',
'                                  AND cc.cc_id = w.customer_contract_id',
'    LEFT JOIN pt_schedule            s ON w.workorder_id = s.workorder_id',
'    INNER JOIN pt_employees           e ON s.empid = e.empid',
'    INNER JOIN pt_workorder_status    ws ON w.status_id = ws.status_id',
'    LEFT JOIN pt_payment_details     pd ON w.workorder_id = pd.workorder_id',
'    left join Account_balance ab on ab.customer_id = c.custid and ab.workorder_id = w.workorder_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Customer Workorders'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(215023854821493292)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP:P20_WORKORDER_ID:\#WORKORDER_ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'DARRENWALSH@OUTLOOK.IE'
,p_internal_uid=>215023854821493292
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215023920367493297)
,p_db_column_name=>'WORKORDER_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'WorkorderID'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215025032378493307)
,p_db_column_name=>'DETAILS'
,p_display_order=>21
,p_column_identifier=>'D'
,p_column_label=>'Workorder Details'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215025480504493307)
,p_db_column_name=>'AMOUNT'
,p_display_order=>31
,p_column_identifier=>'E'
,p_column_label=>'Workorder Charge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215085239470888510)
,p_db_column_name=>'SCHEDULE_DATE'
,p_display_order=>51
,p_column_identifier=>'M'
,p_column_label=>'Schedule Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215085305991888511)
,p_db_column_name=>'SCHEDULE_TIME'
,p_display_order=>61
,p_column_identifier=>'N'
,p_column_label=>'Schedule Time'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215085491600888512)
,p_db_column_name=>'EMPLOYEE'
,p_display_order=>71
,p_column_identifier=>'O'
,p_column_label=>'Employee'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215085762860888515)
,p_db_column_name=>'CC_ID'
,p_display_order=>101
,p_column_identifier=>'R'
,p_column_label=>'Customer Contract'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(219171674217099944)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215085840973888516)
,p_db_column_name=>'STATUS'
,p_display_order=>111
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215087787010888535)
,p_db_column_name=>'CUSTOMER'
,p_display_order=>121
,p_column_identifier=>'U'
,p_column_label=>'Customer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215088278395888540)
,p_db_column_name=>'ACCOUNT_BALANCE'
,p_display_order=>151
,p_column_identifier=>'Z'
,p_column_label=>'Account Balance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00PR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(215088809561888546)
,p_db_column_name=>'Make Payment'
,p_display_order=>161
,p_column_identifier=>'AB'
,p_column_label=>'<i>'
,p_column_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::P24_ACCOUNT_BALANCE,P24_WORKORDER_ID,P24_AMOUNT:#ACCOUNT_BALANCE#,#WORKORDER_ID#,#ACCOUNT_BALANCE#'
,p_column_linktext=>'#Make Payment#'
,p_column_link_attr=>'class="t-Button hot"'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220604640024323836)
,p_db_column_name=>'View Schedule'
,p_display_order=>171
,p_column_identifier=>'AC'
,p_column_label=>'View Schedule'
,p_column_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::P22_WORKORDER_ID,P22_SCHEDULE_DATE:#WORKORDER_ID#,#SCHEDULE_DATE#'
,p_column_linktext=>'#View Schedule#'
,p_column_link_attr=>'class="t-Button hot"'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(220605039751323840)
,p_db_column_name=>'LOCATION'
,p_display_order=>181
,p_column_identifier=>'AD'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(215030628408493645)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2150307'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKORDER_ID:CUSTOMER:CC_ID:DETAILS:SCHEDULE_DATE:SCHEDULE_TIME:AMOUNT:EMPLOYEE:STATUS:ACCOUNT_BALANCE:Make Payment:'
,p_sort_column_1=>'SCHEDULE_DATE'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(215030289975493329)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(215023496746493292)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(146117652757837330)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Workorder'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20'
);
wwv_flow_api.component_end;
end;
/
