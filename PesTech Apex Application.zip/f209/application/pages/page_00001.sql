prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(146140362370837412)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'PesTech Pest Management Application'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DARRENWALSH@OUTLOOK.IE'
,p_last_upd_yyyymmddhh24miss=>'20210428222219'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(146152884578837517)
,p_plug_name=>'Dashboard'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(146055105207837253)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(208772543039507811)
,p_plug_name=>'Top 10 Commerical Customers'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146038146502837238)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(208772686925507812)
,p_region_id=>wwv_flow_api.id(208772543039507811)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(208772721846507813)
,p_chart_id=>wwv_flow_api.id(208772686925507812)
,p_seq=>10
,p_name=>'Top 10 Commerical Customers'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CUSTOMER, TOTAL_CHARGE',
'FROM (',
'SELECT',
'   C.COMPANY CUSTOMER,',
'    SUM(NVL(CC.ANNUAL_FEE, 0)+  NVL(W.AMOUNT,0))TOTAL_CHARGE',
'FROM',
'         PT_CUSTOMERS C',
'    LEFT JOIN PT_CUSTOMER_CONTRACTS CC ON C.CUSTID = CC.CUSTID',
'    LEFT JOIN PT_WORKORDERS W ON CC.CUSTID = W.CUSTOMER_ID',
'    WHERE C.CUST_TYPE_ID =2',
'    GROUP BY C.COMPANY)',
'    WHERE ROWNUM <11',
'    ORDER BY TOTAL_CHARGE DESC'))
,p_items_value_column_name=>'TOTAL_CHARGE'
,p_items_label_column_name=>'CUSTOMER'
,p_color=>'#1B8AA6'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(208774703322507833)
,p_chart_id=>wwv_flow_api.id(208772686925507812)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(208774820027507834)
,p_chart_id=>wwv_flow_api.id(208772686925507812)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(208774937055507835)
,p_plug_name=>'Customers By County'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146038146502837238)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(208775060280507836)
,p_region_id=>wwv_flow_api.id(208774937055507835)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(208775166508507837)
,p_chart_id=>wwv_flow_api.id(208775060280507836)
,p_seq=>10
,p_name=>'Customers by county'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    COUNT(c.county)                            AS "Count_COUNTY",',
'    SUM(cc.annual_fee)         AS "Sum_ANNUAL_FEE",',
'    co.county',
'FROM',
'         pt_customers c',
'    INNER JOIN pt_customer_contracts cc ON c.custid = cc.custid',
'    INNER JOIN pt_counties co ON c.county = a203196.co.county_id',
'GROUP BY',
'    co.county',
'    order by 1 desc , 2 desc'))
,p_items_value_column_name=>'Count_COUNTY'
,p_items_label_column_name=>'COUNTY'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(208775495395507840)
,p_plug_name=>'Sales By Employee'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(146038146502837238)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(208775580978507841)
,p_region_id=>wwv_flow_api.id(208775495395507840)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(208775624715507842)
,p_chart_id=>wwv_flow_api.id(208775580978507841)
,p_seq=>10
,p_name=>'Employee Sales'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SUM(fee) AS total_charges, REP FROM (',
'',
'SELECT',
'SUM(cc.annual_fee) AS fee,',
'E.first_name ||'' ''||E.last_name AS REP    ',
'',
'FROM',
'     pt_customers C',
'INNER JOIN pt_customer_contracts cc ON C.custid = cc.custid',
'INNER JOIN pt_employees E ON cc.rep_id = E.empid',
'',
'GROUP BY',
'E.first_name,',
'E.last_name',
'',
'UNION ',
'',
'SELECT',
'SUM(w.amount) AS fee,',
' E.first_name ||'' ''||E.last_name AS REP ',
'FROM',
'     pt_workorders w',
'INNER JOIN pt_schedule S ON S.workorder_id = w.workorder_id',
'INNER JOIN pt_employees E ON S.empid = E.empid',
'GROUP BY',
'E.first_name,',
'E.last_name)',
'GROUP BY REP',
'ORDER BY total_charges DESC;'))
,p_items_value_column_name=>'TOTAL_CHARGES'
,p_items_label_column_name=>'REP'
,p_color=>'#1B8AA6'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(208775921027507845)
,p_chart_id=>wwv_flow_api.id(208775580978507841)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(208776054604507846)
,p_chart_id=>wwv_flow_api.id(208775580978507841)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(220602313227323813)
,p_name=>'Workorder Status Metrics'
,p_template=>wwv_flow_api.id(146038146502837238)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--circular:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with DATA AS (',
'SELECT ',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id  where status_id = 1 and CT.call_type_id = 1 ) as OPEN_CALL_OUTS,',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where status_id = 2 and CT.call_type_id = 1 ) as CLOSED_CALL_OUTS,',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where status_id = 3 and CT.call_type_id = 1 ) as ON_HOLD_CALL_OUTS,',
'',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where status_id = 1 and CT.call_type_id = 2) as OPEN_FOLLOWUP_CALLS,',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where status_id = 2 and CT.call_type_id = 2) as CLOSED_FOLLOWUP_CALLS,',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where status_id = 3 and CT.call_type_id = 2) as ON_HOLD_FOLLOWUP_CALLS,',
'',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where w.status_id = 1 and CT.call_type_id = 3) as OPEN_ROUTINE_CALLS,',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where status_id = 2 and CT.call_type_id = 3) as CLOSED_ROUTINE_CALLS,',
'(select count(*) from pt_workorders w  JOIN  pt_call_type CT ON W.call_type_id =  CT.call_type_id where status_id = 3 and CT.call_type_id = 3) as ON_HOLD_ROUTINE_CALLS',
'FROM dual',
')',
'select DISTINCT',
'data.OPEN_CALL_OUTS as OPEN_CALLOUTS,',
'data.CLOSED_CALL_OUTS as CLOSED_CALLOUTS ,',
'data.ON_HOLD_CALL_OUTS as ON_HOLD_CALLOUTS,',
'',
'data.OPEN_FOLLOWUP_CALLS as OPEN_FOLLOWUP_CALL,',
'data.CLOSED_FOLLOWUP_CALLS as CLOSED_FOLLOWUP_CALL,',
'data.ON_HOLD_FOLLOWUP_CALLS as ON_HOLD_FOLLOWUP_CALL,',
'',
'data.OPEN_ROUTINE_CALLS as OPEN_ROUTINE_CALL,',
'data.CLOSED_ROUTINE_CALLS as CLOSED_ROUTINE_CALL,',
'data.ON_HOLD_ROUTINE_CALLS as ON_HOLD_ROUTINE_CALL',
'from data;'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(146067082495837272)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220603556344323825)
,p_query_column_id=>1
,p_column_alias=>'OPEN_CALLOUTS'
,p_column_display_sequence=>10
,p_column_heading=>'Open Callouts'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#OPEN_CALLOUTS#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220603670800323826)
,p_query_column_id=>2
,p_column_alias=>'CLOSED_CALLOUTS'
,p_column_display_sequence=>20
,p_column_heading=>'Closed Callouts'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#CLOSED_CALLOUTS#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220603712368323827)
,p_query_column_id=>3
,p_column_alias=>'ON_HOLD_CALLOUTS'
,p_column_display_sequence=>30
,p_column_heading=>'On Hold Callouts'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#ON_HOLD_CALLOUTS#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220603827718323828)
,p_query_column_id=>4
,p_column_alias=>'OPEN_FOLLOWUP_CALL'
,p_column_display_sequence=>40
,p_column_heading=>'Open Followup Call'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#OPEN_FOLLOWUP_CALL#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220603958176323829)
,p_query_column_id=>5
,p_column_alias=>'CLOSED_FOLLOWUP_CALL'
,p_column_display_sequence=>50
,p_column_heading=>'Closed Followup Call'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#CLOSED_FOLLOWUP_CALL#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220604007743323830)
,p_query_column_id=>6
,p_column_alias=>'ON_HOLD_FOLLOWUP_CALL'
,p_column_display_sequence=>60
,p_column_heading=>'On Hold Followup Call'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#ON_HOLD_FOLLOWUP_CALL#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220604105876323831)
,p_query_column_id=>7
,p_column_alias=>'OPEN_ROUTINE_CALL'
,p_column_display_sequence=>70
,p_column_heading=>'Open Routine Call'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#OPEN_ROUTINE_CALL#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220604234803323832)
,p_query_column_id=>8
,p_column_alias=>'CLOSED_ROUTINE_CALL'
,p_column_display_sequence=>80
,p_column_heading=>'Closed Routine Call'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#CLOSED_ROUTINE_CALL#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(220604379886323833)
,p_query_column_id=>9
,p_column_alias=>'ON_HOLD_ROUTINE_CALL'
,p_column_display_sequence=>90
,p_column_heading=>'On Hold Routine Call'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#ON_HOLD_ROUTINE_CALL#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
