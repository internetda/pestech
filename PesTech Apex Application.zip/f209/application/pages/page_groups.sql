prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 209
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(146145254557837469)
,p_group_name=>'Administration'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(146436739399778825)
,p_group_name=>'Customers'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(146436843693780219)
,p_group_name=>'HR'
);
wwv_flow_api.component_end;
end;
/
