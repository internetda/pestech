prompt --application/shared_components/user_interface/lovs/em_training_type
begin
--   Manifest
--     EM_TRAINING TYPE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(226644656028423917)
,p_lov_name=>'EM_TRAINING TYPE'
,p_lov_query=>'.'||wwv_flow_api.id(226644656028423917)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(226644968332423926)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Sales'
,p_lov_return_value=>'Sales'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(226645228605423933)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Technical'
,p_lov_return_value=>'Technical'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(226645667808423934)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Customer Service'
,p_lov_return_value=>'Customer Service'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(226646065196423934)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Administration'
,p_lov_return_value=>'Administration'
);
wwv_flow_api.component_end;
end;
/
