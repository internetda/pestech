prompt --application/shared_components/user_interface/lovs/scheduletime_lov
begin
--   Manifest
--     SCHEDULETIME_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(226613921432130780)
,p_lov_name=>'SCHEDULETIME_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH thirty AS',
'    (SELECT TRUNC(sysdate) + (LEVEL * 30)/(24*60) c_time',
'     FROM dual',
'      CONNECT BY LEVEL <= (24*60) / 30',
'    )',
'  SELECT to_char(c_time, ''hh24:mi'') start_time,',
'         to_char(c_time + 30 / (24 * 60), ''hh24:mi'') end_time',
'   FROM thirty',
'   WHERE EXTRACT(HOUR FROM CAST (c_time AS TIMESTAMP)) BETWEEN 8 AND 18;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'START_TIME'
,p_display_column_name=>'START_TIME'
,p_default_sort_column_name=>'START_TIME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
