prompt --application/shared_components/user_interface/lovs/customers
begin
--   Manifest
--     CUSTOMERS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(146434870910651921)
,p_lov_name=>'CUSTOMERS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT CASE WHEN COMPANY IS NULL THEN  FIRST_NAME||'' ''||LAST_NAME',
'  ELSE COMPANY END AS D,',
'   CUSTID R',
'  FROM PT_CUSTOMERS;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
