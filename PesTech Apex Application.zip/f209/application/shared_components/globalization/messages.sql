prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 209
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41608858746905442
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'A203196'
);
null;
wwv_flow_api.component_end;
end;
/
